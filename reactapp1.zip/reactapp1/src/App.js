import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import Products from './Components/Products';
import AddProduct from './Components/AddProduct';
import UpdateProduct from './Components/UpdateProduct';


function App() {
  return (

    <Router>
      <Link to='/'>Products</Link>
      <Link to='/add-product'>Add Product</Link>



      <Route exact path='/' component={Products} />
      <Route exact path='/add-product' component={AddProduct} />
      <Route exact path='/edit-product/:id' render={(props) => <UpdateProduct {...props} />} />
    </Router>
  );
}

export default App;
