import React from 'react';
import Product from './Product'
import AddProduct from './AddProduct';
import { Link } from 'react-router-dom'

class Products extends React.Component {
  state = {
    products: []
  }

  async componentDidMount() {
    const products = await (await fetch('http://localhost:3004/products')).json();
    this.setState({ products: products })

  }

  render() {
    const products = this.state.products;
    return (
      <div>
        <div>
          {/* <AddProduct /> */}
   
        </div>
        {products.map((product, index) => <Product product={product} key={index} />)}
      </div>
    )
  }
}

export default Products;