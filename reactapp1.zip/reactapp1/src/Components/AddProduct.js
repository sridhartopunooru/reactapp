import React from 'react';
import uuidv4 from 'uuid/v4';

class AddProduct extends React.Component {
  state = {
    name: '',
    cost: '', 
  }

  onChangeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value })
  }

  onClickHandler = () => {
    const product = this.state;
    product.id=uuidv4();
    console.log(product);
    fetch('http://localhost:3004/products', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(product)
    }).then(() => console.log('Added products'))
      .catch((err) => console.log(err))
  }
  render() {
    return (
      <div>
        <div>
          <label>Product Name:</label>
          <input type='text' name='name' value={this.state.name} onChange={this.onChangeHandler} />
        </div>
        <div>
          <label>Product Cost:</label>
          <input type='text' name='cost' value={this.state.cost} onChange={this.onChangeHandler} />
        </div>
        <button onClick={this.onClickHandler}>Add Product</button>
      </div>
    )
  }
}

export default AddProduct;