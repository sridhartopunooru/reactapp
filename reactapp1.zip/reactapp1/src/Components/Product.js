import React from 'react';
import { Link } from 'react-router-dom'

export default ({ product }) => {
    return (
        <div>
            {product.name} - {product.cost} <Link to={`/edit-product/${product.id}`}>Edit</Link>
        </div>
    )
}