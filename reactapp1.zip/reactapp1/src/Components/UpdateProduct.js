import React from 'react';

class UpdateProduct extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name:'',
      cost:''
    }
  }

  onChangeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value })
  }

  onClickHandler = () => {
    const product = this.state;  
    console.log(product);
    fetch(`http://localhost:3004/products/${this.props.match.params.id}`, {
      method: 'PATCH',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(product)
    }).then(() => console.log('Product Updated'))
      .catch((err) => console.log(err))
  }

  componentDidMount() {
    const productId = this.props.match.params.id;
    fetch(`http://localhost:3004/products/${productId}`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
    })
      .then((res) => res.json())
      .then(res => {  
        this.setState(res);
      })
      .catch((err) => console.log(err))
  }
  render() {
    console.log(this.state);
    return (
      <div>
        <div>
          <label>Product Name:</label>
          <input type='text' name='name' value={this.state.name} onChange={this.onChangeHandler} />
        </div>
        <div>
          <label>Product Cost:</label>
          <input type='text' name='cost' value={this.state.cost} onChange={this.onChangeHandler} />
        </div>
        <button onClick={this.onClickHandler}>Update Product</button>
      </div>
    )
  }
}

export default UpdateProduct;